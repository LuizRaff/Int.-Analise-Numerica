#ifndef GAUSS_H
#define GAUSS_H

void gauss (int n, double** a, double* b, double* x);

#endif