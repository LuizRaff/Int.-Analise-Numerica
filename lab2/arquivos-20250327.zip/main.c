#include "raiz.h"
#include <math.h>
#include <stdio.h>

#define PI 3.1415926535897932384626433832795

// exemplo para contagem de avaliacoes da funcao
// defina N=0 antes de chamar o metodo da bissecao
int N;
static double f1 (double x)
{
  N++;
  return x*x*x + x - 7;
}

//static double f2 (double x)
//{
//  N++;
//  return ...;
//}

int main (void)
{
  // adicione aqui os seus testes...
  return 0;
}

