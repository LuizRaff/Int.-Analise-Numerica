#ifndef TAYLOR_H
#define TAYLOR_H

double avalia_taylor (int n, double* c, double x0, double x);
double avalia_seno (int n, double x);

#endif


