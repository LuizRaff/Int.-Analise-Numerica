#include "taylor.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define PI 3.141592653589793

int main (void)
{
  // escreva seu teste aqui
  return 0;
}
