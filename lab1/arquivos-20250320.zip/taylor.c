#include "taylor.h"
#include <stdlib.h>